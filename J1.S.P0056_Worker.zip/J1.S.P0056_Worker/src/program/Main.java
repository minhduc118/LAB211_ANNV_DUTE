package program;

import controller.ManagementController;

public class Main {
    public static void main(String[] args) {
        ManagementController controller = new ManagementController();
        controller.run();
    }
}
